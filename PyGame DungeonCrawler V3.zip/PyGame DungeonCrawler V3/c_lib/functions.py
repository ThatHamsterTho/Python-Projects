def value_in_range(value, min, max):
    return (value >= min) and (value <= max)


def rect_overlap(a, b):
    x_overlap = value_in_range(a.x, b.x, b.x + b.w) or value_in_range(b.x, a.x, a.x + a.w)

    y_overlap = value_in_range(a.y, b.y, b.y + b.h) or value_in_range(b.y, a.y, a.y + a.h)

    return x_overlap and y_overlap


def overlap_area_fun(a, b):
    x_overlap = max(0, min(a.x2, b.x2) - max(a.x, b.x))
    y_overlap = max(0, min(a.y2, b.y2) - max(a.y, b.y))
    overlap_area = x_overlap * y_overlap
    return x_overlap, y_overlap, overlap_area


def dist(a, b):
    return abs(abs(a.c_x - b.c_x) - ((a.w + b.w) / 2)), abs(abs(a.c_y - b.c_y) - ((a.h + b.h) / 2))


def point_in_rect(x, y, rect):
    if rect.x2 > x >= rect.x and rect.y2 > y >= rect.y:
        return True
    else:
        return False


def map_func(x, in_min, in_max, out_min, out_max):
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min


def check_placed(wall, room, remove, area_list):
    search_able_areas = area_list.copy()
    search_able_areas.remove(room)
    if len(search_able_areas) == 0:
        return False
    for R in search_able_areas:
        # see in what room the wall is
        # create a rectangle of the room
        from variables import window
        rect_area = Rectangle(R.x, R.y, R.x_size * window.block_size, R.y_size * window.block_size)
        if point_in_rect(wall.x, wall.y, rect_area):
            del rect_area
            # get the rectangles that overlap given wall
            overlapping_rect = check_xy(wall.x, wall.y, R.wall_obj.wall_list)
            from Screen.create_area import Hallway
            # don't place any new rectangles if the wall is inside a hallway only remove those
            if type(R) == Hallway and not remove:
                return True
            if overlapping_rect is not None:
                # wall is placed
                overlapping_rect.wall_colour = (200, 0, 200)
                if remove and not overlapping_rect.corner:
                    R.wall_obj.wall_list.remove(overlapping_rect)
                # return True for there is a overlapping rect
                return True

    return False


def check_xy(x_co, y_co, my_unfiltered_list):
    return next(filter(lambda x: (x.x == x_co and x.y == y_co), my_unfiltered_list), None)


class Rectangle:
    def __init__(self, x, y, w, h):
        self.c_x = x + w / 2
        self.c_y = y + h / 2
        self.x = x
        self.y = y
        self.x2 = x + w
        self.y2 = y + h
        self.w = w
        self.h = h

    def __del__(self):
        pass




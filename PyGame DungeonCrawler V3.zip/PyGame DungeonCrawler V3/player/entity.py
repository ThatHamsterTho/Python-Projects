import pygame

from c_lib.functions import point_in_rect, Rectangle
from variables import area, window


class Entity:
    surface = pygame.Surface((50, 100))
    surface.fill((200, 200, 0))
    w, h = surface.get_size()

    def __init__(self, x, y):
        self.x, self.y = x - self.w / 2, y - self.h / 2
        self.speed = 5
        self.in_room = None

    def set_room(self, room):
        self.in_room = room

    def move(self, direction):
        for dire_ in direction:
            if dire_ == pygame.K_UP:
                self.y -= self.speed
            elif dire_ == pygame.K_DOWN:
                self.y += self.speed
            if dire_ == pygame.K_LEFT:
                self.x -= self.speed
            elif dire_ == pygame.K_RIGHT:
                self.x += self.speed

    def move_room(self, direction):
        for dire_ in direction:
            if dire_ == pygame.K_UP:
                for surface in window.sub_surface:
                    surface.y += self.speed
            elif dire_ == pygame.K_DOWN:
                for surface in window.sub_surface:
                    surface.y -= self.speed
            if dire_ == pygame.K_LEFT:
                for surface in window.sub_surface:
                    surface.x += self.speed
            elif dire_ == pygame.K_RIGHT:
                for surface in window.sub_surface:
                    surface.x -= self.speed

        inside_of = []
        for R in area.area_list:
            rect_area = Rectangle(R.x, R.y, R.x_size * window.block_size, R.y_size * window.block_size)

            if point_in_rect(self.x, self.y, rect_area):
                inside_of.append(R)

            del rect_area

        print([R.area_num for R in area.area_list])

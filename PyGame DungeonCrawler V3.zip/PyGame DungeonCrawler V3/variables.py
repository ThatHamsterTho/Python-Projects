from Screen.Window import Window

window = Window()

from Screen.create_area import CreateArea

area = CreateArea()

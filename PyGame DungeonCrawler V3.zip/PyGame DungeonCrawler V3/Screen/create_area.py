import pygame
from variables import window
from c_lib.functions import check_placed

block_size = window.block_size


class CreateArea:

    def __init__(self):
        self.rooms = []
        self.room_variables = []  # variables used to create room

        self.hallways = []
        self.hallway_variables = []

        self.area_list = []
        self.area_list_variables = []

    def create_room(self, x, y, x_size, y_size, is_open):
        x = x * block_size
        y = y * block_size
        num = len(self.rooms)  # id of the room in its own list
        area_num = len(self.area_list)  # id of the room in global list ( area_list )
        # store the variables used to create the room
        variables = [x, y, x_size, y_size, num, area_num, is_open]
        # create the room
        room = Room(variables[0], variables[1], variables[2], variables[3], variables[4], variables[5], variables[6])
        # add the room to the lists and store the variables
        self.rooms.append(room)
        self.room_variables.append(variables)
        self.area_list.append(room)
        self.area_list_variables.append(variables)
        # create the walls of the room
        room.create_walls(self.area_list)
        room.draw()

    def create_hallway(self, x, y, x_size, y_size, is_vertical):
        x = x * block_size
        y = y * block_size
        num = len(self.hallways)  # id of the room in its own list
        area_num = len(self.area_list)  # id of the room in global list ( area_list )
        # store the variables used to create the room
        variables = [x, y, x_size, y_size, num, area_num, is_vertical]
        # create the room
        hallway = Hallway(variables[0], variables[1], variables[2], variables[3], variables[4], variables[5], variables[6])
        # add the room to the lists and store the variables
        self.hallways.append(hallway)
        self.hallway_variables.append(variables)
        self.area_list.append(hallway)
        self.area_list_variables.append(variables)
        # create the walls of the room
        hallway.create_walls(self.area_list)
        hallway.draw()

    def sort(self):
        try:
            import operator
        except ImportError:
            key_fun = lambda x: x.count  # use a lambda if no operator module
        else:
            key_fun = operator.attrgetter("count")  # use operator since it's faster than lambda

        self.area_list.sort(key=key_fun, reverse=True)  # sort in-place


class Room:

    def __init__(self, x, y, x_size, y_size, num, area_num, is_open):
        self.x, self.y = x, y
        self.x_size, self.y_size = x_size, y_size
        self.num, self.area_num = num, area_num

        self.surface = pygame.Surface((self.x_size * block_size, self.y_size * block_size), pygame.SRCALPHA)
        self.surface.fill((200, 200, 200, 0))

        self.wall_obj = WallList(self)
        self.is_open = is_open

    def create_walls(self, area_list):
        # j makes it jump from top to bottom with either 0 * (self.y_size - 1) * block_size or 1 * (self.y_size - 1) * block-size

        # create corners
        for j in range(2):
            # to get to the bottom row on second iteration get the size of the room - 1 for the y coordinate
            # create corners

            # left corner
            if not check_placed(wall=Wall(x=0, y=j * block_size * (self.y_size - 1), corner=True, surface=self, num=99),
                                room=self,
                                remove=False,
                                area_list=area_list):
                self.wall_obj.create_wall(x=0,
                                          y=j * block_size * (self.y_size - 1),
                                          corner=True)
            # right corner
            if not check_placed(wall=Wall(x=block_size * (self.x_size - 1), y=j * block_size * (self.y_size - 1), corner=True, surface=self, num=99),
                                room=self,
                                remove=False,
                                area_list=area_list):
                self.wall_obj.create_wall(x=block_size * (self.x_size - 1),
                                          y=j * block_size * (self.y_size - 1),
                                          corner=True)

        # horizontal walls
        for j in range(2):
            for i in range(self.x_size - 2):
                x = (i * block_size) + block_size
                y = j * (self.y_size - 1) * block_size

                if not check_placed(wall=Wall(x, y, corner=False, surface=self, num=99),
                                    room=self,
                                    remove=self.is_open,
                                    area_list=area_list):
                    self.wall_obj.create_wall(x, y, corner=False)

        # vertical walls
        for j in range(2):
            for i in range(self.y_size - 2):
                x = j * (self.x_size - 1) * block_size
                y = i * block_size + block_size

                if not check_placed(wall=Wall(x, y, corner=False, surface=self, num=99),
                                    room=self,
                                    remove=self.is_open,
                                    area_list=area_list):
                    self.wall_obj.create_wall(x, y, corner=False)

    def draw(self):
        window.sub_surface.append(self)


class Hallway:

    def __init__(self, x, y, x_size, y_size, num, area_num, is_vertical):
        self.x, self.y = x, y
        if is_vertical:
            self.x_size, self.y_size = x_size, y_size
        else:
            self.x_size, self.y_size = y_size, x_size

        self.num, self.area_num = num, area_num

        self.surface = pygame.Surface((self.x_size * block_size, self.y_size * block_size), pygame.SRCALPHA)
        self.surface.fill((200, 200, 200, 0))

        self.wall_obj = WallList(self)
        self.vertical = is_vertical

    def create_walls(self, area_list):
        # create horizontal walls
        for j in range(2):
            # to get to the bottom row on second iteration get the size of the room - 1 for the y coordinate
            # create inner walls
            for i in range(self.y_size):
                # determine x y coordinates
                if self.vertical:
                    x = j * (self.x_size - 1) * block_size
                    y = i * block_size
                else:
                    x = i * block_size
                    y = j * (self.y_size - 1) * block_size
                # check if a wall is already placed
                if not check_placed(wall=Wall(x, y, corner=False, surface=self, num=99),
                                    room=self,
                                    remove=False,
                                    area_list=area_list):
                        # place wall
                        self.wall_obj.create_wall(x, y, 0)

                for k in range(1, self.x_size - 1):
                    if self.vertical:
                        x = block_size * k
                        y = y
                    else:
                        x = x
                        y = block_size * k

                    check_placed(wall=Wall(x, y, corner=False, surface=self, num=99),
                                 room=self,
                                 remove=True,
                                 area_list=area_list)

    def draw(self):
        window.sub_surface.append(self)


class Wall:
    wall_colour = (200, 0, 0, 128)

    # create a wall and draw that on the surface
    def __init__(self, x, y, corner, surface, num):
        self.surface = surface
        self.corner = corner
        self.num = num
        self.x, self.y = x + self.surface.x, y + self.surface.y
        self.wall = pygame.Rect(x, y, block_size, block_size)

    def draw(self):
        pygame.draw.rect(self.surface.surface, self.wall_colour, self.wall)

    def draw_rect(self, outline_color, border=1):
        self.surface.surface.fill(outline_color, self.wall)
        self.surface.surface.fill(self.wall_colour, self.wall.inflate(-border * 2, -border * 2))


class WallList:

    # list of the walls in an area
    def __init__(self, area):
        self.area = area
        self.wall_list = []

    # draws a wall to the screen and adds it to the wall_list
    def create_wall(self, x, y, corner):
        num = len(self.wall_list)
        wall = Wall(x, y, corner, self.area, num)
        self.wall_list.append(wall)

    def draw(self):
        for wall in self.wall_list:
            wall.draw_rect((200, 200, 200), 2)

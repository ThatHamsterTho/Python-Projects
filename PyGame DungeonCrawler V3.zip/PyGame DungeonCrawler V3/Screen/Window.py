from ctypes import windll

import pygame

user32 = windll.user32


class Window:
    video_flags = pygame.RESIZABLE | pygame.DOUBLEBUF | pygame.HWSURFACE

    def __init__(self):
        info = pygame.display.Info()

        self.MonitorSize = info.current_w - 10, info.current_h - 50
        # self.MonitorSize = 1000, 1000
        self.block_size = 40

        self.game_name = "Bit Dungeon V2"
        self.screen = pygame.display.set_mode(self.MonitorSize, self.video_flags)
        pygame.display.set_caption(self.game_name)
        self.screen.fill((100, 100, 100))

        self.frame_size = int(round((self.MonitorSize[0] - (self.block_size * 8)) / (
                self.block_size * 2)) * self.block_size * 2), \
                          int(round((self.MonitorSize[1] - (self.block_size * 8)) / (
                                  self.block_size * 2)) * self.block_size * 2)
        self.sub_surface = []

        self.pos = (self.MonitorSize[0] - self.frame_size[0]) / 2, (self.MonitorSize[1] - self.frame_size[1]) / 2

        self.MainFrame = pygame.Surface(self.frame_size)
        self.background = pygame.Surface(self.frame_size)
        self.background.fill((0, 0, 0))

        self.player = None

        user32.ShowWindow(pygame.display.get_wm_info()['window'], 3)

    def resize(self, event):
        self.MonitorSize = (event.w, event.h)
        self.screen = pygame.display.set_mode((event.w, event.h), self.video_flags)
        self.screen.fill((100, 100, 100))
        self.MainFrame = pygame.Surface(self.frame_size)
        self.draw()

    def draw(self):
        self.MainFrame.blit(self.background, (0, 0))
        for subsurface in self.sub_surface:
            from Screen.create_area import Room, Hallway
            if type(subsurface) in {Room, Hallway}:
                subsurface.wall_obj.draw()
            self.MainFrame.blit(subsurface.surface, (subsurface.x, subsurface.y))

        self.MainFrame.blit(self.player.surface, (self.player.x, self.player.y))
        self.screen.blit(self.MainFrame, self.pos)
        pygame.display.update(self.MainFrame.get_rect())
        pygame.display.update(self.screen.get_rect())

    def set_player(self, Player):
        self.player = Player


pygame.init()

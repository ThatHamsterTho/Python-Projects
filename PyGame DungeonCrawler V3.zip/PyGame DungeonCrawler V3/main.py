import pygame
import sys

from player.entity import Entity
from variables import area, window


def main():
    clock = pygame.time.Clock()
    fps = 60
    clock.tick(fps)

    player = Entity(window.frame_size[0] / 2, window.frame_size[1] / 2)
    window.set_player(player)

    area.create_room(0, 0, 50, 50, False)
    area.create_room(10, 10, 20, 20, True)
    area.create_room(10, 15, 10, 10, True)
    # area.create_room(25, 0, 25, 25, True)

    pygame.display.flip()

    direction = []
    moving = False

    running = True

    while running:

        # event
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.VIDEORESIZE:
                window.resize(event)

            if event.type == pygame.KEYDOWN:
                direction.append(event.key)
                moving = True
            if event.type == pygame.KEYUP:
                direction.remove(event.key)
                if len(direction) == 0:
                    moving = False

        if moving:
            window.player.move_room(direction)

        window.draw()

    pygame.quit()
    sys.exit()


if __name__ == '__main__':
    main()

import pygame
import random
import time
from Classes.Screen.Create_Screen import window, block_size
from C_Lib.functions import *


class Area:

    def __init__(self):
        self.rooms = []
        self.room_os = []
        self.h_hallways = []
        self.v_hallways = []
        self.area_list = []
        self.walls = []
        self.background = pygame.Surface((window.frame_width, window.frame_height))
        self.background.fill((0, 0, 0))

    def room(self, x, y, x_size, y_size):
        num = len(self.rooms)
        area_num = len(self.area_list)
        room = Room(x, y, x_size, y_size, num, area_num)
        room.create_room(self.area_list, self.walls)
        self.rooms.append(room)
        self.area_list.append(room)

    def room_o(self, x, y, x_size, y_size, c):
        num = len(self.room_os)
        area_num = len(self.area_list)
        room = RoomO(x, y, x_size, y_size, num, area_num, c)
        room.create_room(self.area_list, self.walls)
        self.rooms.append(room)
        self.area_list.append(room)
        return room

    def h_hallway(self, x, y, x_size, y_size):
        num = len(self.h_hallways)
        area_num = len(self.area_list)
        hallway = HHallway(x, y, x_size, y_size, num, area_num)
        hallway.create_room(self.area_list, self.walls)
        self.h_hallways.append(hallway)
        self.area_list.append(hallway)

    def v_hallway(self, x, y, x_size, y_size):
        num = len(self.v_hallways)
        area_num = len(self.area_list)
        hallway = VHallway(x, y, x_size, y_size, num, area_num)
        hallway.create_room(self.area_list, self.walls)
        self.v_hallways.append(hallway)
        self.area_list.append(hallway)

    def draw(self):
        window.MainFrame.blit(self.background, (0, 0))
        for room in self.area_list:
            room.draw()

    def generate_rooms(self):
        self.area_list[:] = []

        def generate_rooms(amount, room_list_, min_size, max_size, c):
            for i in range(amount):
                if len(room_list_) > 0:
                    rect_a_list = []
                    for room__ in room_list_:
                        rect_a = Rect(room__.x, room__.y, room__.size_x * block_size,
                                      room__.size_y * block_size)
                        rect_a_list.append(rect_a)
                    pos = self.generate_pos(min_size, max_size)
                    rect_b = Rect(pos[0], pos[1], pos[2] * block_size, pos[3] * block_size)
                    itt_ = 0
                    while True:
                        if itt_ > 15:
                            break
                        cont = False
                        for rect_a in rect_a_list:
                            if rect_overlap(rect_a, rect_b):
                                cont = True
                        if not cont:
                            break
                        else:
                            pos = self.generate_pos(min_size, max_size)
                            rect_b = Rect(pos[0], pos[1], pos[2] * block_size, pos[3] * block_size)
                            itt_ += 1
                    if itt_ < 15:
                        room = self.room_o(pos[0], pos[1], pos[2], pos[3], c)
                        room_list.append(room)
                else:
                    pos = self.generate_pos(min_size, max_size)
                    room = self.room_o(pos[0], pos[1], pos[2], pos[3], c)
                    room_list.append(room)

        room_list = []

        iteration = 0
        while len(room_list) < 7 and iteration < 50:
            iteration += 1
            random.seed(int(round(time.time() * 1000)) / iteration * (iteration / time.time_ns()))
            generate_rooms(2, room_list, 15, 23, (0, 200, 0, 128))
            generate_rooms(4, room_list, 12, 20, (0, 0, 200, 128))
            generate_rooms(8, room_list, 10, 15, (0, 200, 200, 128))

        def generate_paths():

            def room_filter(cr):
                room_list_ = room_list.copy()
                room_list_.remove(cr)

                max_hall_way_length = 7

                for r in room_list_:
                    if cr not in r.connected_to:
                        if True:
                            if r.x2 < cr.x or r.x > cr.x2:
                                r_a = Rect(r.x, r.y, r.size_x * block_size, r.size_y * block_size)
                                r_b = Rect(cr.x, cr.y, cr.size_x * block_size, cr.size_y * block_size)
                                if overlap_area_fun(r_a, r_b)[1] >= 4 * block_size and dist(r_a, r_b)[0] < max_hall_way_length * block_size:
                                    """print(f"room {r.area_num} is a good match for {cr.area_num}, "
                                          f"{overlap_area_fun(r_a, r_b)[1]}, "
                                          f"distance between them is: {dist(r_a, r_b)[0]}. "
                                          f"room {r.area_num} x: {r.x}, x2: {r.x2} "
                                          f"room {cr.area_num} x: {cr.x}, x2: {cr.x2}")"""
                                    cr.connected_to.append(r)
                            if r.y2 < cr.y or r.y > cr.y2:
                                r_a = Rect(r.x, r.y, r.size_x * block_size, r.size_y * block_size)
                                r_b = Rect(cr.x, cr.y, cr.size_x * block_size, cr.size_y * block_size)
                                if overlap_area_fun(r_a, r_b)[0] >= 4 * block_size and dist(r_a, r_b)[1] < max_hall_way_length * block_size:
                                    """print(f"room {r.area_num} is a good match for {cr.area_num}, "
                                          f"{overlap_area_fun(r_a, r_b)[1]}, "
                                          f"distance between them is: {dist(r_a, r_b)[0]}. "
                                          f"room {r.area_num} x: {r.x}, x2: {r.x2} "
                                          f"room {cr.area_num} x: {cr.x}, x2: {cr.x2}")"""
                                    cr.connected_to.append(r)

            for room in room_list:
                room_filter(room)
                connected_to_list = [r.area_num for r in room.connected_to]
                a = Rect(room.x, room.y, room.size_x * block_size, room.size_y * block_size)
                print(f"{room.area_num} is connected to {connected_to_list}")
                for con_r in room.connected_to:
                    b = Rect(con_r.x, con_r.y, con_r.size_x * block_size, con_r.size_y * block_size)
                    rel_pos = position_to_rect(a, b)



        generate_paths()

        self.draw()

    @staticmethod
    def generate_pos(min_size, max_size):
        size_x = random.randint(min_size, max_size)
        size_y = random.randint(min_size, max_size)
        x = random.randint(0, (window.frame_width / block_size) - size_x) * block_size
        y = random.randint(0, (window.frame_height / block_size) - size_y) * block_size

        x2 = x + (size_x * block_size)
        y2 = y + (size_y * block_size)
        return x, y, size_x, size_y, x2, y2


class Room:

    def __init__(self, x, y, x_size, y_size, num, area_num):
        (self.x, self.y, self.size_x, self.size_y) = (x, y, x_size, y_size)
        self.num = num
        self.area_num = area_num
        self.Room = pygame.Surface((self.size_x * block_size, self.size_y * block_size), pygame.SRCALPHA)
        self.Room.fill((200, 200, 200, 0))
        self.wall_obj = WallList(self.Room, self.x, self.y, self.area_num)
        self.removed_walls = []

    def create_room(self, area_list, walls):
        # create horizontal walls
        for j in range(2):
            # to get to the bottom row on second iteration get the size of the room - 1 for the y coordinate
            # create corners
            if check_placed(self.x,
                            self.y + (j * block_size * (self.size_y - 1)),
                            area_list):
                # place corner
                self.wall_obj.create_wall(0, j * block_size * (self.size_y - 1), 1, walls)
            if check_placed(self.x + (block_size * (self.size_x - 1)),
                            self.y + (j * block_size * (self.size_y - 1)),
                            area_list):
                # place corner
                self.wall_obj.create_wall(block_size * (self.size_x - 1),
                                          j * block_size * (self.size_y - 1), 1, walls)

            # create inner walls
            for i in range(self.size_x - 2):
                # determine x y coordinates
                x = i * block_size + block_size
                y = j * block_size * (self.size_y - 1)
                # place wall
                self.wall_obj.create_wall(x, y, 0, walls)

        # create vertical walls
        for j in range(2):
            for i in range(self.size_y - 2):
                # determine x y coordinates
                x = j * block_size * (self.size_x - 1)
                y = i * block_size + block_size
                # place wall
                if check_placed(x + self.x, y + self.y, area_list):
                    # place wall
                    self.wall_obj.create_wall(x, y, 0, walls)

    def draw(self):
        self.wall_obj.draw()
        window.MainFrame.blit(self.Room, (self.x, self.y))
        pygame.display.update(window.MainFrame.get_rect())


class RoomO:

    def __init__(self, x, y, x_size, y_size, num, area_num, c):
        (self.x, self.y, self.size_x, self.size_y) = (x, y, x_size, y_size)
        self.c_x = self.x + ((self.size_x / 2) * block_size)
        self.c_y = self.y + ((self.size_y / 2) * block_size)
        self.x2 = self.x + self.size_x * block_size
        self.y2 = self.y + self.size_y * block_size
        self.connected_to = []
        self.num = num
        self.area_num = area_num
        self.Room = pygame.Surface((self.size_x * block_size, self.size_y * block_size), pygame.SRCALPHA)
        self.Room.fill(c)
        self.wall_obj = WallList(self.Room, self.x, self.y, self.area_num)
        self.removed_walls = []

    def create_room(self, area_list, walls):
        # create horizontal walls
        for j in range(2):
            # to get to the bottom row on second iteration get the size of the room - 1 for the y coordinate
            # create corners
            if check_placed(self.x,
                            self.y + (j * block_size * (self.size_y - 1)),
                            area_list):
                # place corner
                self.wall_obj.create_wall(0, j * block_size * (self.size_y - 1), 1, walls)
            if check_placed(self.x + (block_size * (self.size_x - 1)),
                            self.y + (j * block_size * (self.size_y - 1)),
                            area_list):
                # place corner
                self.wall_obj.create_wall(block_size * (self.size_x - 1),
                                          j * block_size * (self.size_y - 1), 1, walls)

            # create inner walls
            for i in range(self.size_x - 2):
                # determine x y coordinates
                x = i * block_size + block_size
                y = j * block_size * (self.size_y - 1)
                if check_placed(x + self.x, y + self.y, area_list):
                    # place wall
                    self.wall_obj.create_wall(x, y, 0, walls)
                else:
                    remove_placed(x + self.x, y + self.y, area_list, walls)

        # create vertical walls
        for j in range(2):
            for i in range(self.size_y - 2):
                # determine x y coordinates
                x = j * block_size * (self.size_x - 1)
                y = i * block_size + block_size
                if check_placed(x + self.x, y + self.y, area_list):
                    # place wall
                    self.wall_obj.create_wall(x, y, 0, walls)
                else:
                    remove_placed(x + self.x, y + self.y, area_list, walls)

    def draw(self):
        self.wall_obj.draw()
        font = pygame.font.SysFont('Arial', 21)
        self.Room.blit(font.render(str(self.area_num), True, (250, 0, 0)), (((self.size_x / 2) * block_size),
                                                                            ((self.size_y / 2) * block_size)))
        window.MainFrame.blit(self.Room, (self.x, self.y))
        pygame.display.update(window.MainFrame.get_rect())


class HHallway:

    def __init__(self, x, y, x_size, y_size, num, area_num):
        (self.x, self.y, self.size_x, self.size_y) = (x, y, x_size, y_size)
        self.num = num
        self.area_num = area_num
        self.Room = pygame.Surface((self.size_x * block_size, self.size_y * block_size), pygame.SRCALPHA)
        self.Room.fill((200, 200, 200, 0))
        self.wall_obj = WallList(self.Room, self.x, self.y, self.area_num)
        self.removed_walls = []

    def create_room(self, area_list, walls):
        # create horizontal walls
        for j in range(2):
            # to get to the bottom row on second iteration get the size of the room - 1 for the y coordinate
            # create inner walls
            for i in range(self.size_x):
                # determine x y coordinates
                x = i * block_size
                y = j * (self.size_y - 1) * block_size
                if check_placed(x + self.x, y + self.y, area_list):
                    # place wall
                    self.wall_obj.create_wall(x, y, 0, walls)
                for k in range(1, self.size_y - 1):
                    remove_placed(x + self.x, self.y + block_size * k, area_list, walls)

    def draw(self):
        self.wall_obj.draw()
        window.MainFrame.blit(self.Room, (self.x, self.y))
        pygame.display.update(window.MainFrame.get_rect())


class VHallway:

    def __init__(self, x, y, x_size, y_size, num, area_num):
        (self.x, self.y, self.size_x, self.size_y) = (x, y, x_size, y_size)
        self.num = num
        self.area_num = area_num
        self.Room = pygame.Surface((self.size_x * block_size, self.size_y * block_size), pygame.SRCALPHA)
        self.Room.fill((200, 200, 200, 0))
        self.wall_obj = WallList(self.Room, self.x, self.y, self.area_num)

    def create_room(self, area_list, walls):
        # create horizontal walls
        for j in range(2):
            # to get to the bottom row on second iteration get the size of the room - 1 for the y coordinate
            # create inner walls
            for i in range(self.size_y):
                # determine x y coordinates
                x = j * (self.size_x - 1) * block_size
                y = i * block_size
                # place wall
                if check_placed(x + self.x, y + self.y, area_list):
                    # place wall
                    self.wall_obj.create_wall(x, y, 0, walls)
                for k in range(1, self.size_x - 1):
                    remove_placed(self.x + block_size * k, y + self.y, area_list, walls)

    def draw(self):
        self.wall_obj.draw()
        window.MainFrame.blit(self.Room, (self.x, self.y))
        pygame.display.update(window.MainFrame.get_rect())


class WallList:

    def __init__(self, area, x, y, area_num):
        self.Area = area
        self.walls = []
        self.background_colour = (200, 50, 50, 128)
        self.area_num = area_num
        (self.x, self.y) = (x, y)

    def create_wall(self, x, y, corner, walls):
        wall = Wall(x, y, self.background_colour, self.area_num, corner, x + self.x, y + self.y)
        self.walls.append(wall)
        walls.append(wall)

    def draw(self):
        for wall in self.walls:
            pygame.draw.rect(self.Area, wall.background_colour, wall.wall)
            pygame.display.update(self.Area.get_rect())


class Wall:

    def __init__(self, x, y, colour, area_num, corner, x2, y2):
        self.wall = pygame.Rect(0, 0, block_size, block_size)
        self.wall = self.wall.move(x, y)
        (self.x, self.y) = (x2, y2)
        self.background_colour = colour
        self.area_num = area_num
        self.type = corner

    def __del__(self):
        pass


def check_placed(x, y, area_list):
    for area in area_list:
        rect = Rect(area.x, area.y, block_size * area.size_x, block_size * area.size_y)
        if point_in_rect(x, y, rect):
            for wall in area.wall_obj.walls:
                wall_rect = Rect(wall.wall.left + area.x,
                                 wall.wall.top + area.y,
                                 wall.wall.width,
                                 wall.wall.height)
                if point_in_rect(x, y, wall_rect):
                    return False
                del wall_rect
        del rect
    return True


def remove_placed(x, y, area_list, walls):
    for area in area_list:
        rect = Rect(area.x, area.y, block_size * area.size_x, block_size * area.size_y)
        if point_in_rect(x, y, rect):
            for wall in area.wall_obj.walls:
                wall_rect = Rect(wall.wall.left + area.x,
                                 wall.wall.top + area.y,
                                 wall.wall.width,
                                 wall.wall.height)
                if point_in_rect(x, y, wall_rect) and wall.type != 1:
                    t_pos = []
                    x2 = [wall.x - block_size, wall.x + block_size, wall.x]
                    y2 = [wall.y, wall.y, wall.y - block_size]

                    for i in range(len(x2)):
                        t_pos.append([wall for wall in walls if wall.x == x2[i] and wall.y == y2[i]])

                    count = 0
                    for t in t_pos:
                        if len(t) >= 1:
                            count += 1
                    if not (count > 1):
                        area.wall_obj.walls.remove(wall)
                    del wall
                del wall_rect
        del rect

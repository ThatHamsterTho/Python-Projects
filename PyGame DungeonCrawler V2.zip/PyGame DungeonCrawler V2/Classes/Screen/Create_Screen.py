import pygame
import ctypes

# get monitor size
user32 = ctypes.windll.user32
# MonitorSize = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
MonitorSize = 1600, 1000

block_size = MonitorSize[1]/50
print(block_size)


class Window:

    def __init__(self):
        self.width = MonitorSize[0]
        self.height = MonitorSize[1]

        self.game_name = "Bit Dungeon V2"
        self.screen = pygame.display.set_mode((self.width, self.height), pygame.RESIZABLE)
                                             # pygame.FULLSCREEN | pygame.DOUBLEBUF | pygame.HWSURFACE)
        pygame.display.set_caption(self.game_name)

        self.background_colour = (170, 170, 170)
        self.screen.fill(self.background_colour)

        (self.frame_width, self.frame_height, self.left, self.top) = (500, 500, 1, 1)

        # main frame
        self.frame_width = round((MonitorSize[0] - (block_size * 8)) / (block_size * 2)) * block_size * 2
        self.frame_height = round((MonitorSize[1] - (block_size * 8)) / (block_size * 2)) * block_size * 2

        self.left = (MonitorSize[0] - self.frame_width) / 2
        self.top = (MonitorSize[1] - self.frame_height) / 2

        self.MainFrame = pygame.Surface((self.frame_width, self.frame_height))
        self.MainFrame.fill((0, 0, 0))

        # quit button
        self.Q_buttonColor = (100, 100, 100)
        self.button = pygame.Surface((50, 30))
        self.hover = False

    def draw(self):

        self.screen.blit(self.MainFrame, (self.left, self.top))
        pygame.display.update(self.screen.get_rect())

    def q_button(self):
        font = pygame.font.SysFont('Arial', 21)
        q_rect = pygame.Rect(0, 0, 50, 30)
        pygame.draw.rect(self.button, self.Q_buttonColor, q_rect)
        self.button.blit(font.render('Quit', True, (0, 0, 0)), (0, 0))

        self.screen.blit(self.button, (0, 0))
        pygame.display.update(self.button.get_rect())

    def hover_quit(self):
        if self.button.get_rect().collidepoint(pygame.mouse.get_pos()):
            self.hover = True
            self.Q_buttonColor = (255, 160, 160)
            pygame.display.update(self.button.get_rect())

        if self.hover and not self.button.get_rect().collidepoint(pygame.mouse.get_pos()):
            self.hover = False
            self.Q_buttonColor = (100, 100, 100)
            pygame.display.update(self.button.get_rect())


window = Window()

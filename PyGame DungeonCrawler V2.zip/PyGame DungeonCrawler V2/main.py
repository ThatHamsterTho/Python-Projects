import os

from Classes.Screen.Create_Screen import *
from Classes.Screen.Area import Area
import sys


def initialize():

    area = Area()

    area.generate_rooms()

    area.draw()

    return area


def draw():
    window.q_button()

    window.hover_quit()

    window.draw()


def main():
    pygame.init()
    clock = pygame.time.Clock()
    fps = 60

    area = initialize()

    pygame.display.flip()
    running = True
    while running:

        draw()

        # events

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:
                print("NEW SECTION")
                area.generate_rooms()

            # Quit button

            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = event.pos

                if window.button.get_rect().collidepoint(mouse_pos):
                    # prints current location of mouse
                    running = False

    pygame.quit()
    sys.exit()


if __name__ == '__main__':
    main()

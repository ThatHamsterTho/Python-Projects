import math


def value_in_range(value, min, max):
    return (value >= min) and (value <= max)


def rect_overlap(a, b):
    x_overlap = value_in_range(a.x, b.x, b.x + b.w) or value_in_range(b.x, a.x, a.x + a.w)

    y_overlap = value_in_range(a.y, b.y, b.y + b.h) or value_in_range(b.y, a.y, a.y + a.h)

    return x_overlap and y_overlap


def overlap_area_fun(a, b):
    x_overlap = max(0, min(a.x2, b.x2) - max(a.x, b.x))
    y_overlap = max(0, min(a.y2, b.y2) - max(a.y, b.y))
    overlap_area = x_overlap * y_overlap
    return x_overlap, y_overlap, overlap_area


def dist(a, b):
    return abs(abs(a.c_x - b.c_x) - ((a.w + b.w) / 2)), abs(abs(a.c_y - b.c_y) - ((a.h + b.h) / 2))


def dist_pyt(x1, y1, x2, y2):
    return math.sqrt(pow(abs(x1 - x2), 2) + pow(abs(y1 - y2), 2))


def point_in_rect(x, y, rect):
    if rect.x2 > x >= rect.x and rect.y2 > y >= rect.y:
        return True
    else:
        return False


def position_to_rect(a, b):
    # a is positioned to rect b
    if overlap_area_fun(a, b)[1] > 0:
        # x pos
        if b.x > a.x2:
            return 2
        else:
            return -2
    if overlap_area_fun(a, b)[0] > 0:
        # y pos
        if a.y2 < b.y:
            return -1
        else:
            return 1


class Rect:
    def __init__(self, x, y, w, h):
        self.c_x = x + w / 2
        self.c_y = y + h / 2
        self.x = x
        self.y = y
        self.x2 = x + w
        self.y2 = y + h
        self.w = w
        self.h = h

    def __del__(self):
        pass
